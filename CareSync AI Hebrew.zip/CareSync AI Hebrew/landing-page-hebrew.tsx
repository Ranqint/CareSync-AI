import React, { useState, useEffect } from 'react'
import { motion, useScroll, useTransform } from 'framer-motion'
import { useInView } from 'react-intersection-observer'
import { AlertCircle, Calendar, Clock, CreditCard, Heart, Home, MessageCircle, Smartphone, Zap, MessageSquare, Bell } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

const FeatureCard = ({ icon, title, description }) => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 50 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.5, type: "spring", stiffness: 100 }}
    >
      <Card className="h-full bg-white/10 backdrop-blur-md border-none shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-teal-500">
            {icon}
            {title}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <CardDescription className="text-gray-200">{description}</CardDescription>
        </CardContent>
      </Card>
    </motion.div>
  )
}

const ParallaxText = ({ children, baseVelocity = 100 }) => {
  const [ref, inView] = useInView({
    triggerOnce: false,
    threshold: 0,
  })
  const baseX = useTransform(useScroll(), [0, 1], [0, baseVelocity])

  return (
    <div ref={ref} className="parallax">
      <motion.div
        className="scroller"
        style={{ x: baseX }}
        animate={{ x: inView ? [-1000, 0] : 0 }}
        transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
      >
        <span>{children} </span>
        <span>{children} </span>
        <span>{children} </span>
        <span>{children} </span>
      </motion.div>
    </div>
  )
}

export default function LandingPageHebrew() {
  const { scrollYProgress } = useScroll()
  const opacity = useTransform(scrollYProgress, [0, 0.5], [1, 0])
  const scale = useTransform(scrollYProgress, [0, 0.5], [1, 0.8])

  return (
    <div dir="rtl" className="min-h-screen bg-gradient-to-b from-blue-900 via-teal-900 to-emerald-900 font-['Varela Round'] text-white">
      <motion.header 
        className="sticky top-0 z-50 bg-white/10 backdrop-blur-md shadow-lg"
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ type: "spring", stiffness: 100, damping: 20 }}
      >
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Heart className="w-8 h-8 text-teal-500" />
            <span className="text-2xl font-bold text-teal-500">CareSync AI</span>
          </div>
          <nav>
            <ul className="flex gap-6">
              <li><a href="#features" className="text-gray-300 hover:text-teal-500 transition-colors">יתרונות</a></li>
              <li><a href="#whatsapp" className="text-gray-300 hover:text-teal-500 transition-colors">וואטסאפ</a></li>
              <li><a href="#pricing" className="text-gray-300 hover:text-teal-500 transition-colors">תכניות</a></li>
              <li><a href="#integration" className="text-gray-300 hover:text-teal-500 transition-colors">אינטגרציה</a></li>
            </ul>
          </nav>
          <Button className="bg-teal-500 hover:bg-teal-600 text-white">התחל עכשיו</Button>
        </div>
      </motion.header>

      <main>
        <section className="py-20 relative overflow-hidden">
          <motion.div 
            className="absolute inset-0 z-0"
            style={{
              backgroundImage: "url('/placeholder.svg?height=1080&width=1920')",
              backgroundSize: 'cover',
              backgroundPosition: 'center',
              opacity,
              scale
            }}
          />
          <div className="container mx-auto px-4 relative z-10">
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="text-center"
            >
              <h1 className="text-5xl font-bold mb-6 text-teal-500">הדרך החכמה לטיפול באהובים שלך</h1>
              <p className="text-xl text-gray-300 mb-8">
                CareSync AI: העוזר האישי החכם שלך לניהול טיפול מושלם. עם תזכורות כפולות למטפלים ולמטופלים, תוכלו סוף סוף לישון בשקט, בידיעה שכל פרט חשוב מטופל.
              </p>
              <Button size="lg" className="mr-4 bg-teal-500 hover:bg-teal-600 text-white">נסו בחינם עכשיו</Button>
              <Button size="lg" variant="outline" className="border-teal-500 text-teal-500 hover:bg-teal-500 hover:text-white">גלו איך זה עובד</Button>
            </motion.div>
          </div>
        </section>

        <ParallaxText baseVelocity={-5}>CareSync AI - הטיפול המושלם לאהובים שלך</ParallaxText>

        <section id="features" className="py-20 bg-gradient-to-r from-blue-900 to-teal-900">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12 text-teal-500">הכירו את המהפכה בטיפול המשפחתי</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              <FeatureCard
                icon={<Clock className="w-6 h-6 text-teal-500" />}
                title="תזכורות תרופות חכמות"
                description="שכחתם את התרופות של סבתא? לא עוד. המערכת שלנו מבטיחה שכל מנה תילקח בזמן, כל יום."
              />
              <FeatureCard
                icon={<Calendar className="w-6 h-6 text-teal-500" />}
                title="ניהול פגישות ללא מאמץ"
                description="תיאום תורים לרופא היה פעם סיוט? עכשיו זה קל כמו לחיצת כפתור."
              />
              <FeatureCard
                icon={<MessageCircle className="w-6 h-6 text-teal-500" />}
                title="תיאום מטפלים מושלם"
                description="סוף לבלבול ולתקשורת לקויה. כולם מסונכרנים, תמיד."
              />
              <FeatureCard
                icon={<AlertCircle className="w-6 h-6 text-teal-500" />}
                title="התראות חירום מצילות חיים"
                description="שקט נפשי אמיתי: תקבלו התראה מיידית ברגע שמשהו לא בסדר."
              />
              <FeatureCard
                icon={<Smartphone className="w-6 h-6 text-teal-500" />}
                title="הכל בכף ידך"
                description="נהלו את הטיפול מכל מקום, בכל זמן, עם האפליקציה הידידותית שלנו."
              />
              <FeatureCard
                icon={<Zap className="w-6 h-6 text-teal-500" />}
                title="תובנות AI מתקדמות"
                description="קבלו המלצות טיפול מותאמות אישית, כאילו יש לכם רופא צמוד 24/7."
              />
            </div>
          </div>
        </section>

        <section id="whatsapp" className="py-20 bg-gradient-to-r from-teal-900 to-emerald-900">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12 text-teal-500">CareSync AI בוואטסאפ - פשוט כמו לדבר עם חבר</h2>
            <div className="flex flex-wrap items-center justify-center gap-12">
              <motion.div
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5 }}
                className="w-full md:w-1/2 max-w-md"
              >
                <Card className="bg-white/10 backdrop-blur-md border-none shadow-lg">
                  <CardHeader>
                    <CardTitle className="text-teal-500">ככה נראה טיפול בעידן החדש</CardTitle>
                    <CardDescription className="text-gray-300">פשוט, מהיר ואפקטיבי - בדיוק כמו שאתם אוהבים</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-start gap-2">
                      <div className="bg-teal-500 text-white p-2 rounded-lg">CareSync AI</div>
                      <p className="bg-white/20 p-2 rounded-lg">בוקר טוב! זמן לתרופת הבוקר של אבא. האם הוא כבר לקח אותה?</p>
                    </div>
                    <div className="flex items-start gap-2 justify-end">
                      <p className="bg-blue-500 text-white p-2 rounded-lg">תודה על התזכורת! נתתי לו כרגע.</p>
                      <div className="bg-gray-300 p-2 rounded-full">את/ה</div>
                    </div>
                    <div className="flex items-start gap-2">
                      <div className="bg-teal-500 text-white p-2 rounded-lg">CareSync AI</div>
                      <p className="bg-white/20 p-2 rounded-lg">מצוין! עדכנתי את היומן. אל תשכחו - יש ביקור רופא ב-14:00 היום.</p>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
              <motion.div
                initial={{ opacity: 0, x: -50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5 }}
                className="w-full md:w-1/2 max-w-md"
              >
                <h3 className="text-2xl font-semibold mb-4 text-teal-500">למה וואטסאפ? כי החיים צריכים להיות פשוטים</h3>
                <ul className="space-y-4 text-gray-300">
                  <li className="flex items-center gap-2">
                    <MessageSquare className="w-6 h-6 text-teal-500" />
                    <span>נוח וקל לשימוש - גם לסבתא שלכם</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <Clock className="w-6 h-6 text-teal-500" />
                    <span>עדכונים בזמן אמת - כי כל דקה חשובה</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <MessageCircle className="w-6 h-6 text-teal-500" />
                    <span>תקשורת חלקה בין כל המטפלים</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <Smartphone className="w-6 h-6 text-teal-500" />
                    <span>אין צורך להתקין אפליקציה נוספת</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <Bell className="w-6 h-6 text-teal-500" />
                    <span>תזכורות כפולות - כי שניים טובים מאחד</span>
                  </li>
                </ul>
              </motion.div>
            </div>
          </div>
        </section>

        <section id="pricing" className="py-20 bg-gradient-to-r from-blue-900 to-teal-900">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12 text-teal-500">השקעה קטנה, תמורה  ענקית</h2>
            <div className="flex flex-wrap justify-center gap-8">
              <motion.div
                initial={{ opacity: 0, y: 50 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.2 }}
              >
                <Card className="w-full max-w-sm bg-white/10 backdrop-blur-md border-none shadow-lg">
                  <CardHeader>
                    <CardTitle className="text-teal-500">תכנית משפחתית</CardTitle>
                    <CardDescription className="text-gray-300">הפתרון המושלם למשפחות אכפתיות</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-4xl font-bold mb-4 text-teal-500">₪80<span className="text-lg font-normal">/חודש</span></p>
                    <ul className="list-disc list-inside mb-6 text-gray-300">
                      <li>תזכורות תרופות חכמות</li>
                      <li>ניהול פגישות מתקדם</li>
                      <li>תיאום מטפלים אוטומטי</li>
                      <li>התראות חירום מהירות</li>
                      <li>אינטגרציה מלאה עם וואטסאפ</li>
                    </ul>
                  </CardContent>
                  <CardFooter>
                    <Button className="w-full bg-teal-500 hover:bg-teal-600 text-white">התחילו עכשיו</Button>
                  </CardFooter>
                </Card>
              </motion.div>
              <motion.div
                initial={{ opacity: 0, y: 50 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.4 }}
              >
                <Card className="w-full max-w-sm bg-teal-500/20 backdrop-blur-md border-none shadow-lg">
                  <CardHeader>
                    <CardTitle className="text-teal-500">תכנית פרימיום מגובה ביטוח</CardTitle>
                    <CardDescription className="text-gray-300">הטיפול המקיף ביותר, במימון חברת הביטוח שלכם</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-4xl font-bold mb-4 text-teal-500">₪0<span className="text-lg font-normal">/חודש</span></p>
                    <ul className="list-disc list-inside mb-6 text-gray-300">
                      <li>כל היתרונות של התכנית המשפחתית</li>
                      <li>מערכת התראות חירום מתקדמת</li>
                      <li>תמיכה אישית 24/7</li>
                      <li>דוחות טיפול מקיפים כל רבעון</li>
                      <li>קדימות בתמיכה בוואטסאפ</li>
                    </ul>
                  </CardContent>
                  <CardFooter>
                    <Button className="w-full bg-teal-500 hover:bg-teal-600 text-white">בדקו זכאות עכשיו</Button>
                  </CardFooter>
                </Card>
              </motion.div>
            </div>
          </div>
        </section>

        <section id="integration" className="py-20 bg-gradient-to-r from-teal-900 to-emerald-900">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12 text-teal-500">הבית החכם בשירות הטיפול</h2>
            <div className="flex flex-wrap items-center justify-center gap-12">
              <motion.div
                initial={{ opacity: 0, scale: 0.5 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5 }}
                className="text-center"
              >
                <Home className="w-16 h-16 text-teal-500 mx-auto mb-4" />
                <p className="text-lg font-semibold text-teal-500">מכשירי בית חכם</p>
              </motion.div>
              <motion.div
                initial={{ opacity: 0, scale: 0.5 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: 0.2 }}
                className="text-center"
              >
                <AlertCircle className="w-16 h-16 text-teal-500 mx-auto mb-4" />
                <p className="text-lg font-semibold text-teal-500">זיהוי נפילות מתקדם</p>
              </motion.div>
              <motion.div
                initial={{ opacity: 0, scale: 0.5 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: 0.4 }}
                className="text-center"
              >
                <Heart className="w-16 h-16 text-teal-500 mx-auto mb-4" />
                <p className="text-lg font-semibold text-teal-500">ניטור בריאות רציף</p>
              </motion.div>
            </div>
            <p className="text-center mt-8 text-gray-300">
              CareSync AI משתלב בצורה חלקה עם מכשירי הבית החכם שלכם, מספק מעקב מקיף ושולח עדכונים בזמן אמת ישירות לוואטסאפ שלכם.
            </p>
          </div>
        </section>
      </main>

      <footer className="bg-blue-900 text-gray-300 py-12">
        <div className="container mx-auto px-4">
          <div className="flex flex-wrap justify-between">
            <div className="w-full md:w-1/3 mb-8 md:mb-0">
              <h3 className="text-2xl font-bold mb-4 text-teal-500">CareSync AI</h3>
              <p>מעצימים משפחות לספק את הטיפול הטוב ביותר ליקיריהם, עם טכנולוגיה מתקדמת ואינטגרציה חכמה לוואטסאפ.</p>
            </div>
            <div className="w-full md:w-1/3 mb-8 md:mb-0">
              <h4 className="text-xl font-semibold mb-4 text-teal-500">קישורים מהירים</h4>
              <ul className="space-y-2">
                <li><a href="#features" className="hover:text-teal-500 transition-colors">יתרונות</a></li>
                <li><a href="#whatsapp" className="hover:text-teal-500 transition-colors">וואטסאפ</a></li>
                <li><a href="#pricing" className="hover:text-teal-500 transition-colors">תכניות</a></li>
                <li><a href="#integration" className="hover:text-teal-500 transition-colors">אינטגרציה</a></li>
              </ul>
            </div>
            <div className="w-full md:w-1/3">
              <h4 className="text-xl font-semibold mb-4 text-teal-500">צרו קשר</h4>
              <p>דוא"ל: support@caresyncai.com</p>
              <p>טלפון: 1-700-700-700</p>
              <p>וואטסאפ: 050-123-4567</p>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-teal-800 text-center">
            <p>&copy; 2023 CareSync AI. כל הזכויות שמורות.</p>
          </div>
        </div>
      </footer>
      <style jsx global>{`
        @import url('https://fonts.googleapis.com/css2?family=Varela+Round&display=swap');

        html {
          font-family: 'Varela Round', sans-serif;
        }

        .parallax {
          overflow: hidden;
          letter-spacing: -2px;
          line-height: 0.8;
          margin: 0;
          white-space: nowrap;
          display: flex;
          flex-wrap: nowrap;
        }

        .parallax .scroller {
          font-weight: 600;
          text-transform: uppercase;
          font-size: 64px;
          display: flex;
          white-space: nowrap;
          display: flex;
          flex-wrap: nowrap;
        }

        .parallax span {
          display: block;
          margin-right: 30px;
        }
      `}</style>
    </div>
  )
}