import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { useInView } from 'react-intersection-observer'
import { AlertCircle, Calendar, Clock, CreditCard, Heart, Home, MessageCircle, Smartphone, Zap, MessageSquare, Bell } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import '@fontsource/varela-round'

const FeatureCard = ({ icon, title, description }) => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 50 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.5 }}
    >
      <Card className="h-full bg-sky-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            {icon}
            {title}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <CardDescription>{description}</CardDescription>
        </CardContent>
      </Card>
    </motion.div>
  )
}

export default function LandingPageHebrew() {
  const [scrollY, setScrollY] = useState(0)

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY)
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  return (
    <div dir="rtl" className="min-h-screen bg-gradient-to-b from-orange-50 to-sky-100 font-['Varela Round']">
      <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md shadow-sm">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Heart className="w-8 h-8 text-orange-500" />
            <span className="text-2xl font-bold text-orange-500">CareSync AI</span>
          </div>
          <nav>
            <ul className="flex gap-6">
              <li><a href="#features" className="text-muted-foreground hover:text-orange-500 transition-colors">יתרונות</a></li>
              <li><a href="#whatsapp" className="text-muted-foreground hover:text-orange-500 transition-colors">וואטסאפ</a></li>
              <li><a href="#pricing" className="text-muted-foreground hover:text-orange-500 transition-colors">תכניות</a></li>
              <li><a href="#integration" className="text-muted-foreground hover:text-orange-500 transition-colors">אינטגרציה</a></li>
            </ul>
          </nav>
          <Button>התחל עכשיו</Button>
        </div>
      </header>

      <main>
        <section className="py-20">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="text-center"
            >
              <h1 className="text-5xl font-bold mb-6 text-orange-500">הדרך החכמה לטיפול באהובים שלך</h1>
              <p className="text-xl text-muted-foreground mb-8">
                CareSync AI: העוזר האישי החכם שלך לניהול טיפול מושלם. עם תזכורות כפולות למטפלים ולמטופלים, תוכלו סוף סוף לישון בשקט, בידיעה שכל פרט חשוב מטופל.
              </p>
              <Button size="lg" className="ml-4">נסו בחינם עכשיו</Button>
              <Button size="lg" variant="outline">גלו איך זה עובד</Button>
            </motion.div>
          </div>
        </section>

        <section id="features" className="py-20 bg-white">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12 text-orange-500">הכירו את המהפכה בטיפול המשפחתי</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              <FeatureCard
                icon={<Clock className="w-6 h-6 text-orange-500" />}
                title="תזכורות תרופות חכמות"
                description="שכחתם את התרופות של סבתא? לא עוד. המערכת שלנו מבטיחה שכל מנה תילקח בזמן, כל יום."
              />
              <FeatureCard
                icon={<Calendar className="w-6 h-6 text-orange-500" />}
                title="ניהול פגישות ללא מאמץ"
                description="תיאום תורים לרופא היה פעם סיוט? עכשיו זה קל כמו לחיצת כפתור."
              />
              <FeatureCard
                icon={<MessageCircle className="w-6 h-6 text-orange-500" />}
                title="תיאום מטפלים מושלם"
                description="סוף לבלבול ולתקשורת לקויה. כולם מסונכרנים, תמיד."
              />
              <FeatureCard
                icon={<AlertCircle className="w-6 h-6 text-orange-500" />}
                title="התראות חירום מצילות חיים"
                description="שקט נפשי אמיתי: תקבלו התראה מיידית ברגע שמשהו לא בסדר."
              />
              <FeatureCard
                icon={<Smartphone className="w-6 h-6 text-orange-500" />}
                title="הכל בכף ידך"
                description="נהלו את הטיפול מכל מקום, בכל זמן, עם האפליקציה הידידותית שלנו."
              />
              <FeatureCard
                icon={<Zap className="w-6 h-6 text-orange-500" />}
                title="תובנות AI מתקדמות"
                description="קבלו המלצות טיפול מותאמות אישית, כאילו יש לכם רופא צמוד 24/7."
              />
              <FeatureCard
                icon={<MessageSquare className="w-6 h-6 text-orange-500" />}
                title="וואטסאפ בשירות הטיפול"
                description="נהלו את הטיפול דרך הפלטפורמה המוכרת ביותר - פשוט, מהיר ונוח."
              />
              <FeatureCard
                icon={<Bell className="w-6 h-6 text-orange-500" />}
                title="תזכורות כפולות - הסוד שלנו"
                description="הבטיחו טיפול מושלם עם תזכורות למטפלים ולמטופלים. אף פרט לא יישכח."
              />
            </div>
          </div>
        </section>

        <section id="whatsapp" className="py-20 bg-gradient-to-b from-sky-50 to-sky-100">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12 text-orange-500">CareSync AI בוואטסאפ - פשוט כמו לדבר עם חבר</h2>
            <div className="flex flex-wrap items-center justify-center gap-12">
              <motion.div
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5 }}
                className="w-full md:w-1/2 max-w-md"
              >
                <Card className="bg-white shadow-lg">
                  <CardHeader>
                    <CardTitle>ככה נראה טיפול בעידן החדש</CardTitle>
                    <CardDescription>פשוט, מהיר ואפקטיבי - בדיוק כמו שאתם אוהבים</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-start gap-2">
                      <div className="bg-sky-500 text-white p-2 rounded-lg">CareSync AI</div>
                      <p className="bg-gray-100 p-2 rounded-lg">בוקר טוב! זמן לתרופת הבוקר של אבא. האם הוא כבר לקח אותה?</p>
                    </div>
                    <div className="flex items-start gap-2 justify-end">
                      <p className="bg-blue-500 text-white p-2 rounded-lg">תודה על התזכורת! נתתי לו כרגע.</p>
                      <div className="bg-gray-300 p-2 rounded-full">את/ה</div>
                    </div>
                    <div className="flex items-start gap-2">
                      <div className="bg-sky-500 text-white p-2 rounded-lg">CareSync AI</div>
                      <p className="bg-gray-100 p-2 rounded-lg">מצוין! עדכנתי את היומן. אל תשכחו - יש ביקור רופא ב-14:00 היום.</p>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
              <motion.div
                initial={{ opacity: 0, x: -50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5 }}
                className="w-full md:w-1/2 max-w-md"
              >
                <h3 className="text-2xl font-semibold mb-4 text-orange-500">למה וואטסאפ? כי החיים צריכים להיות פשוטים</h3>
                <ul className="space-y-4">
                  <li className="flex items-center gap-2">
                    <MessageSquare className="w-6 h-6 text-sky-500" />
                    <span>נוח וקל לשימוש - גם לסבתא שלכם</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <Clock className="w-6 h-6 text-sky-500" />
                    <span>עדכונים בזמן אמת - כי כל דקה חשובה</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <MessageCircle className="w-6 h-6 text-sky-500" />
                    <span>תקשורת חלקה בין כל המטפלים</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <Smartphone className="w-6 h-6 text-sky-500" />
                    <span>אין צורך להתקין אפליקציה נוספת</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <Bell className="w-6 h-6 text-sky-500" />
                    <span>תזכורות כפולות - כי שניים טובים מאחד</span>
                  </li>
                </ul>
              </motion.div>
            </div>
          </div>
        </section>

        <section id="pricing" className="py-20">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12 text-orange-500">השקעה קטנה, תמורה ענקית</h2>
            <div className="flex flex-wrap justify-center gap-8">
              <Card className="w-full max-w-sm">
                <CardHeader>
                  <CardTitle>תכנית משפחתית</CardTitle>
                  <CardDescription>הפתרון המושלם למשפחות אכפתיות</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-4xl font-bold mb-4 text-orange-500">₪80<span className="text-lg font-normal">/חודש</span></p>
                  <ul className="list-disc list-inside mb-6">
                    <li>תזכורות תרופות חכמות</li>
                    <li>ניהול פגישות מתקדם</li>
                    <li>תיאום מטפלים אוטומטי</li>
                    <li>התראות חירום מהירות</li>
                    <li>אינטגרציה מלאה עם וואטסאפ</li>
                  </ul>
                </CardContent>
                <CardFooter>
                  <Button className="w-full">התחילו עכשיו</Button>
                </CardFooter>
              </Card>
              <Card className="w-full max-w-sm border-orange-500">
                
                <CardHeader>
                  <CardTitle>תכנית פרימיום מגובה ביטוח</CardTitle>
                  <CardDescription>הטיפול המקיף ביותר, במימון חברת הביטוח שלכם</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-4xl font-bold mb-4 text-orange-500">₪0<span className="text-lg font-normal">/חודש</span></p>
                  <ul className="list-disc list-inside mb-6">
                    <li>כל היתרונות של התכנית המשפחתית</li>
                    <li>מערכת התראות חירום מתקדמת</li>
                    <li>תמיכה אישית 24/7</li>
                    <li>דוחות טיפול מקיפים כל רבעון</li>
                    <li>קדימות בתמיכה בוואטסאפ</li>
                  </ul>
                </CardContent>
                <CardFooter>
                  <Button className="w-full">בדקו זכאות עכשיו</Button>
                </CardFooter>
              </Card>
            </div>
          </div>
        </section>

        <section id="integration" className="py-20 bg-white">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12 text-orange-500">הבית החכם בשירות הטיפול</h2>
            <div className="flex flex-wrap items-center justify-center gap-12">
              <motion.div
                initial={{ opacity: 0, scale: 0.5 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5 }}
                className="text-center"
              >
                <Home className="w-16 h-16 text-orange-500 mx-auto mb-4" />
                <p className="text-lg font-semibold text-orange-500">מכשירי בית חכם</p>
              </motion.div>
              <motion.div
                initial={{ opacity: 0, scale: 0.5 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: 0.2 }}
                className="text-center"
              >
                <AlertCircle className="w-16 h-16 text-orange-500 mx-auto mb-4" />
                <p className="text-lg font-semibold text-orange-500">זיהוי נפילות מתקדם</p>
              </motion.div>
              <motion.div
                initial={{ opacity: 0, scale: 0.5 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: 0.4 }}
                className="text-center"
              >
                <Heart className="w-16 h-16 text-orange-500 mx-auto mb-4" />
                <p className="text-lg font-semibold text-orange-500">ניטור בריאות רציף</p>
              </motion.div>
            </div>
            <p className="text-center mt-8 text-muted-foreground">
              CareSync AI משתלב בצורה חלקה עם מכשירי הבית החכם שלכם, מספק מעקב מקיף ושולח עדכונים בזמן אמת ישירות לוואטסאפ שלכם.
            </p>
          </div>
        </section>
      </main>

      <footer className="bg-orange-900 text-orange-50 py-12">
        <div className="container mx-auto px-4">
          <div className="flex flex-wrap justify-between">
            <div className="w-full md:w-1/3 mb-8 md:mb-0">
              <h3 className="text-2xl font-bold mb-4 text-orange-500">CareSync AI</h3>
              <p>מעצימים משפחות לספק את הטיפול הטוב ביותר ליקיריהם, עם טכנולוגיה מתקדמת ואינטגרציה חכמה לוואטסאפ.</p>
            </div>
            <div className="w-full md:w-1/3 mb-8 md:mb-0">
              <h4 className="text-xl font-semibold mb-4 text-orange-500">קישורים מהירים</h4>
              <ul className="space-y-2">
                <li><a href="#features" className="hover:text-orange-200 transition-colors">יתרונות</a></li>
                <li><a href="#whatsapp" className="hover:text-orange-200 transition-colors">וואטסאפ</a></li>
                <li><a href="#pricing" className="hover:text-orange-200 transition-colors">תכניות</a></li>
                <li><a href="#integration" className="hover:text-orange-200 transition-colors">אינטגרציה</a></li>
              </ul>
            </div>
            <div className="w-full md:w-1/3">
              <h4 className="text-xl font-semibold mb-4 text-orange-500">צרו קשר</h4>
              <p>דוא"ל: support@caresyncai.com</p>
              <p>טלפון: 1-700-700-700</p>
              <p>וואטסאפ: 050-123-4567</p>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-orange-700 text-center">
            <p>&copy; 2023 CareSync AI. כל הזכויות שמורות.</p>
          </div>
        </div>
      </footer>
      <style jsx global>{`
        @import url('https://fonts.googleapis.com/css2?family=Varela+Round&display=swap');

        html {
          font-family: 'Varela Round', sans-serif;
        }
      `}</style>
    </div>
  )
}